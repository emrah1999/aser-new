<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LbStatus extends Model
{
	protected $table = 'lb_status';
}
