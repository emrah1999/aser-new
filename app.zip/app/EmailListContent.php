<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmailListContent extends Model
{
    protected $table = 'email_list_content';
}
