<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CourierSettings extends Model
{
    protected $table = 'courier_settings';
}
