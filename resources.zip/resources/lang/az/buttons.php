<?php

return [
    'subscribe' => 'Abunə ol',
    'calculate' => 'Hesabla',
    'more_stores' => 'Daha çox mağaza göstər',
    'pay_all' => 'Seçilmişləri ödə',
    'create_courier' => 'Yeni sifariş',
    'create_otp' => 'OTP əlavə et'
];