<?php

return [
    'your_email' => 'Sizin e-mail ünvanınız',
];