<?php

return [
    'email'   => 'E-Mail',
    'password'   => 'Şifrə',
    'subscribe' => 'Sərfəli yeniliklərə abunə ol',
];