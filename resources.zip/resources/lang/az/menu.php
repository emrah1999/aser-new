<?php

return [
    'about' => 'Haqqımızda',
    'tariffs'   => 'Tariflər',
    'sellers'   => 'Mağazalar',
    'transport'   => 'Yük daşıma',
    'faqi'   => 'Tez-tez verilən suallar',
    'contact'   => 'Əlaqə',
    'terms_new'   => 'Şərtlər və qaydalar',
    'main_menus' => 'ƏSAS MENULAR',
    'useful_information' => 'FAYDALI MƏLUMATLAR',
    'prohibited_products' => 'Qadağan olunmuş məhsullar',
    'tutorial' => 'Təlimat',
    'news' => 'Xəbərlər',
    'our_services' => 'Xidmətlərimiz',
];