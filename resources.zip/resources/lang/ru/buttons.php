<?php

return [
    'subscribe' => 'Подписывайся',
    'calculate' => 'Рассчитать',
    'more_stores' => 'Показать больше магазинов',
    'pay_all' => 'Оплатить выбранный',
    'create_courier' => 'New order',
    'create_otp' => 'OTP əlavə et'
];