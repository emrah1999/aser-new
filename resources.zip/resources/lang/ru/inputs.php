<?php

return [
    'your_email' => 'Ваша электронная почта',
];