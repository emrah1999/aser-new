<?php

return [
    'email'   => 'почта',
    'password'   => 'пароль',
    'subscribe' => 'Подписаться на новые новости',
];