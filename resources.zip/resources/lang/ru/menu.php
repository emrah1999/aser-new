<?php

return [
    'about' => 'O нас',
    'tariffs'   => 'Тарифы',
    'sellers'   => 'Магазины',
    'transport'   => 'Yük daşıma',
    'faqi'   => 'Ч.З.В',
    'contact'   => 'Контакт',
    'terms_new'   => 'Условия',
    'main_menus' => 'ОСНОВНЫЕ МЕНЮ',
    'useful_information' => 'Полезная информация',
    'prohibited_products' => 'Запрещенные продукты',
    'tutorial' => 'Руководство',
    'news' => 'Новости',
    'our_services' => 'Услуги',
];