<?php

return [
    'subscribe' => 'Subscribe',
    'calculate' => 'Calculate',
    'more_stores' => 'Show more stores',
    'pay_all' => 'Pay the selected',
    'create_courier' => 'New order',
    'create_otp' => 'OTP əlavə et'

];