<?php

return [
    'your_email' => 'Your e-mail address',
];