<?php

return [
    'email'   => 'E-Mail',
    'password'   => 'Password',
    'subscribe' => 'Subscribe for new news',
];