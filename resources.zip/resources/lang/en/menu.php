<?php

return [
    'about' => 'About',
    'tariffs'   => 'Tariffs',
    'sellers'   => 'Stores',
    'transport'   => 'Yük daşıma',
    'faqi'   => 'F.A.Q',
    'contact'   => 'Contact',
    'terms_new'   => 'Terms',
    'main_menus' => 'MAIN MENUS',
    'useful_information' => 'Useful Information',
    'prohibited_products' => 'Prohibited products',
    'tutorial' => 'Tutorial',
    'news' => 'News',
    'our_services' => 'Our Services',
];