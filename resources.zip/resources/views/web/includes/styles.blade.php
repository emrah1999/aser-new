<link rel="icon" type="text/css" href="{{ asset('web/images/logo/logo.png') }}">
<link rel="stylesheet" type="text/css" href="{{ asset('web/css/library/bootstrap.min.css') }}">
<link rel="stylesheet" type="text/css" href="{{ asset('web/css/library/owl.carousel.min.css') }}">
<link rel="stylesheet" type="text/css" href="{{asset("frontend/css/sweetalert2.min.css")}}">
<link rel="stylesheet" type="text/css" href="{{ asset('web/css/style.css?ver=4.3') }}">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">
