
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                <img src="{{asset("uploads/static/comingSoon.png")}}" alt="" title="" style="width: 100%; height: fit-content">
                </div>
            </div>
        </div>
    </div>
</div>
